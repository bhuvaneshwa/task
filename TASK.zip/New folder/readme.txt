1.cd vasi-ship
2.npm install (download all node modules)
3. npm run start



this build with React with tailwind css