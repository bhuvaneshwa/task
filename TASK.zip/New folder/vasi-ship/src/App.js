
import './App.css';
import React, { useState } from "react";

import guiter from "./image/guiter.jpg";

const productsData = [
  {
    id: 1,
    name: "Product 1",
    category: "Category A",
    description: "Experience musical bliss with our high-quality guitar. Crafted with precision, it delivers exceptional sound and playability. With its solid wood body and comfortable neck, it's perfect for musicians of all levels. Stay in tune with ease, thanks to the top-notch tuning machines. Discover your unique sound with the versatile pickup system. Get ready to unleash your musical talent with this sleek and durable instrument.",
    price: 10.99,
    image:guiter
  },
  {
    id: 2,
    name: "Product 2",
    category: "Category B",
    description: "Experience musical bliss with our high-quality guitar. Crafted with precision, it delivers exceptional sound and playability. With its solid wood body and comfortable neck, it's perfect for musicians of all levels. Stay in tune with ease, thanks to the top-notch tuning machines. Discover your unique sound with the versatile pickup system. Get ready to unleash your musical talent with this sleek and durable instrument.",
    price: 24.99,
    image: guiter
  },
  {
    id: 3,
    name: "Product 3",
    category: "Category B",
    description: "Experience musical bliss with our high-quality guitar. Crafted with precision, it delivers exceptional sound and playability. With its solid wood body and comfortable neck, it's perfect for musicians of all levels. Stay in tune with ease, thanks to the top-notch tuning machines. Discover your unique sound with the versatile pickup system. Get ready to unleash your musical talent with this sleek and durable instrument.",
    price: 24.99,
    image:guiter
  },
 
  {
    id: 4,
    name: "Product 4",
    category: "Category B",
    description: "Experience musical bliss with our high-quality guitar. Crafted with precision, it delivers exceptional sound and playability. With its solid wood body and comfortable neck, it's perfect for musicians of all levels. Stay in tune with ease, thanks to the top-notch tuning machines. Discover your unique sound with the versatile pickup system. Get ready to unleash your musical talent with this sleek and durable instrument.",
    price: 24.99,
    image: guiter
  },
 
  {
    id: 5,
    name: "Product 5",
    category: "Category B",
    description: "Experience musical bliss with our high-quality guitar. Crafted with precision, it delivers exceptional sound and playability. With its solid wood body and comfortable neck, it's perfect for musicians of all levels. Stay in tune with ease, thanks to the top-notch tuning machines. Discover your unique sound with the versatile pickup system. Get ready to unleash your musical talent with this sleek and durable instrument.",
    price: 24.99,
    image: guiter
  },
 
  {
    id: 6,
    name: "Product 6",
    category: "Category B",
    description: "Experience musical bliss with our high-quality guitar. Crafted with precision, it delivers exceptional sound and playability. With its solid wood body and comfortable neck, it's perfect for musicians of all levels. Stay in tune with ease, thanks to the top-notch tuning machines. Discover your unique sound with the versatile pickup system. Get ready to unleash your musical talent with this sleek and durable instrument.",
    price: 24.99,
    image: guiter
  },
 

  {
    id: 7,
    name: "Product 7",
    category: "Category B",
    description: "Experience musical bliss with our high-quality guitar. Crafted with precision, it delivers exceptional sound and playability. With its solid wood body and comfortable neck, it's perfect for musicians of all levels. Stay in tune with ease, thanks to the top-notch tuning machines. Discover your unique sound with the versatile pickup system. Get ready to unleash your musical talent with this sleek and durable instrument.",
    price: 24.99,
    image: guiter
  },
 
  {
    id: 8,
    name: "Product 8",
    category: "Category B",
    description: "Experience musical bliss with our high-quality guitar. Crafted with precision, it delivers exceptional sound and playability. With its solid wood body and comfortable neck, it's perfect for musicians of all levels. Stay in tune with ease, thanks to the top-notch tuning machines. Discover your unique sound with the versatile pickup system. Get ready to unleash your musical talent with this sleek and durable instrument.",
    price: 24.99,
    image: guiter
  },
 
  {
    id: 9,
    name: "Product 9",
    category: "Category B",
    description: "Experience musical bliss with our high-quality guitar. Crafted with precision, it delivers exceptional sound and playability. With its solid wood body and comfortable neck, it's perfect for musicians of all levels. Stay in tune with ease, thanks to the top-notch tuning machines. Discover your unique sound with the versatile pickup system. Get ready to unleash your musical talent with this sleek and durable instrument.",
    price: 24.99,
    image: guiter
  },
 
  {
    id: 10,
    name: "Product 10",
    category: "Category B",
    description: "Experience musical bliss with our high-quality guitar. Crafted with precision, it delivers exceptional sound and playability. With its solid wood body and comfortable neck, it's perfect for musicians of all levels. Stay in tune with ease, thanks to the top-notch tuning machines. Discover your unique sound with the versatile pickup system. Get ready to unleash your musical talent with this sleek and durable instrument.",
    price: 24.99,
    image:guiter
  },
 
  {
    id: 11,
    name: "Product 11",
    category: "Category B",
    description: "Experience musical bliss with our high-quality guitar. Crafted with precision, it delivers exceptional sound and playability. With its solid wood body and comfortable neck, it's perfect for musicians of all levels. Stay in tune with ease, thanks to the top-notch tuning machines. Discover your unique sound with the versatile pickup system. Get ready to unleash your musical talent with this sleek and durable instrument.",
    price: 24.99,
    image:guiter
  },
 
  {
    id: 12,
    name: "Product 12",
    category: "Category B",
    description: "Experience musical bliss with our high-quality guitar. Crafted with precision, it delivers exceptional sound and playability. With its solid wood body and comfortable neck, it's perfect for musicians of all levels. Stay in tune with ease, thanks to the top-notch tuning machines. Discover your unique sound with the versatile pickup system. Get ready to unleash your musical talent with this sleek and durable instrument.",
    price: 24.99,
    image:guiter
  },
 
  {
    id: 13,
    name: "Product 13",
    category: "Category B",
    description: "Experience musical bliss with our high-quality guitar. Crafted with precision, it delivers exceptional sound and playability. With its solid wood body and comfortable neck, it's perfect for musicians of all levels. Stay in tune with ease, thanks to the top-notch tuning machines. Discover your unique sound with the versatile pickup system. Get ready to unleash your musical talent with this sleek and durable instrument.",
    price: 24.99,
    image:guiter
  },
 
  
 
  {
    id: 14,
    name: "Product 14",
    category: "Category C",
    description: "Experience musical bliss with our high-quality guitar. Crafted with precision, it delivers exceptional sound and playability. With its solid wood body and comfortable neck, it's perfect for musicians of all levels. Stay in tune with ease, thanks to the top-notch tuning machines. Discover your unique sound with the versatile pickup system. Get ready to unleash your musical talent with this sleek and durable instrument.",
    price: 15.99,
    image:guiter
  },
  
  {
    id: 15,
    name: "Product 15",
    category: "Category C",
    description: "Experience musical bliss with our high-quality guitar. Crafted with precision, it delivers exceptional sound and playability. With its solid wood body and comfortable neck, it's perfect for musicians of all levels. Stay in tune with ease, thanks to the top-notch tuning machines. Discover your unique sound with the versatile pickup system. Get ready to unleash your musical talent with this sleek and durable instrument.",
    price: 15.99,
    image:guiter
  },
  
  {
    id: 16,
    name: "Product 16",
    category: "Category C",
    description: "Experience musical bliss with our high-quality guitar. Crafted with precision, it delivers exceptional sound and playability. With its solid wood body and comfortable neck, it's perfect for musicians of all levels. Stay in tune with ease, thanks to the top-notch tuning machines. Discover your unique sound with the versatile pickup system. Get ready to unleash your musical talent with this sleek and durable instrument.",
    price: 15.99,
    image:guiter
  },
  
  {
    id: 17,
    name: "Product 17",
    category: "Category C",
    description: "Experience musical bliss with our high-quality guitar. Crafted with precision, it delivers exceptional sound and playability. With its solid wood body and comfortable neck, it's perfect for musicians of all levels. Stay in tune with ease, thanks to the top-notch tuning machines. Discover your unique sound with the versatile pickup system. Get ready to unleash your musical talent with this sleek and durable instrument.",
    price: 15.99,
    image:guiter
  },
  
  {
    id: 18,
    name: "Product 18",
    category: "Category C",
    description: "Experience musical bliss with our high-quality guitar. Crafted with precision, it delivers exceptional sound and playability. With its solid wood body and comfortable neck, it's perfect for musicians of all levels. Stay in tune with ease, thanks to the top-notch tuning machines. Discover your unique sound with the versatile pickup system. Get ready to unleash your musical talent with this sleek and durable instrument.",
    price: 15.99,
    image:guiter
  },
  
  {
    id: 19,
    name: "Product 19",
    category: "Category C",
    description: "Experience musical bliss with our high-quality guitar. Crafted with precision, it delivers exceptional sound and playability. With its solid wood body and comfortable neck, it's perfect for musicians of all levels. Stay in tune with ease, thanks to the top-notch tuning machines. Discover your unique sound with the versatile pickup system. Get ready to unleash your musical talent with this sleek and durable instrument.",
    price: 15.99,
    image:guiter
  },
  
 
];

function App() {
  const [categoryFilter, setCategoryFilter] = useState("");
  const [products, setProducts] = useState(productsData);

  const handleCategoryFilterChange = (event) => {
    const category = event.target.value;
    setCategoryFilter(category);
    setProducts(category ? productsData.filter((product) => product.category === category) : productsData);
  };
  
  return (
    <div className="container px-4 mx-auto sm:px-6 lg:px-8">
    <div className="flex flex-col items-center my-8">
      <h1 className="mb-4 text-3xl font-bold">Product Catalog</h1>
      <label htmlFor="category-filter" className="justify-start text-gray-700">
        Filter by Category:
      </label>
      <div className="relative inline-block ml-2">
        <select
          id="category-filter"
          className="text-gray-700 form-select"
          value={categoryFilter}
          onChange={handleCategoryFilterChange}
        >
          <option value="">All</option>
          <option value="Category A">Category A</option>
          <option value="Category B">Category B</option>
          <option value="Category C">Category C</option>
        </select>
      </div>
    </div>
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
      {products.map((product) => (
        <div key={product.id} className="overflow-hidden bg-white rounded-lg shadow">
          <img src={product.image} alt="" className="object-cover w-full h-48" />
          <div className="px-4 py-2">
            <h2 className="text-lg font-bold">{product.name}</h2>
            <p className="text-justify text-gray-700">{product.description}</p>
            <p className="font-bold text-gray-900">${product.price.toFixed(2)}</p>
          </div>
        </div>
      ))}
    </div>
  </div>
  );
}

export default App;
